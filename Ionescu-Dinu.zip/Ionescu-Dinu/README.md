# Ionescu-Dinu
## Superliga romaniei
* pagina de start
* pagina de login
* pagina de cautare
* pagina vizualizare echipe
* pagina vizualizare stadioane
* pagina vizualizare jucatori
* pagina vizualizare antrenori